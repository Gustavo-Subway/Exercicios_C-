﻿using System;
namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Jogo da Velha  Gustavo S. e Jorge

            var b = new Random();

            int a;
            int d, e, f, g, h, i, j, k, l;
            int a1;

            Console.WriteLine("Digite para Escolher\n");
            Console.WriteLine("1-Jogar");
            Console.WriteLine("2-Instruções");
            Console.WriteLine("3-Sair\n");

            a = int.Parse(Console.ReadLine());

            do
            {
                if (a > 3)
                {
                    Console.WriteLine("Inválido\n");
                }

                if (a == 1)
                {
                    d = 0; e = 0; f = 0;
                    g = 0; h = 0; i = 0;
                    j = 0; k = 0; l = 0;

                    int fim = 0; // 0 = jogando, 1 = terminou, "um boolean" feito com int

                    while (fim == 0)
                    {
                        Console.Clear(); //limpa a tela e coloca o tabuleiro denovo
                        Console.WriteLine($"\t {d} \t|\t {e} \t|\t {f}");
                        Console.WriteLine("\t-----------------------------------");
                        Console.WriteLine($"\t {g} \t|\t {h} \t|\t {i}");
                        Console.WriteLine("\t-----------------------------------");
                        Console.WriteLine($"\t {j} \t|\t {k} \t|\t {l}");

                        Console.WriteLine("\nEscolha uma posição (1 a 9):");
                        a1 = int.Parse(Console.ReadLine());

                        // controles do jogador

                        if (a1 == 1 && d == 0) d = 1;
                        if (a1 == 2 && e == 0) e = 1;
                        if (a1 == 3 && f == 0) f = 1;
                        if (a1 == 4 && g == 0) g = 1;
                        if (a1 == 5 && h == 0) h = 1;
                        if (a1 == 6 && i == 0) i = 1;
                        if (a1 == 7 && j == 0) j = 1;
                        if (a1 == 8 && k == 0) k = 1;
                        if (a1 == 9 && l == 0) l = 1;

                        // vê se o jogador ja venceu

                        if ((d == 1 && e == 1 && f == 1) ||
                            (g == 1 && h == 1 && i == 1) ||
                            (j == 1 && k == 1 && l == 1) ||
                            (d == 1 && g == 1 && j == 1) ||
                            (e == 1 && h == 1 && k == 1) ||
                            (f == 1 && i == 1 && l == 1) ||
                            (d == 1 && h == 1 && l == 1) ||
                            (f == 1 && h == 1 && j == 1))
                        {
                            Console.WriteLine("\nVictory");
                            fim = 1;
                        }

                        // se vitoria, reinicia

                        if (fim == 1) break;

                        // maquina, joga e n joga em lugar ja colocado
                        
                        int a2;

                        do
                        {
                            a2 = b.Next(1, 10);
                        } while ((a2 == 1 && d != 0) ||
                                 (a2 == 2 && e != 0) ||
                                 (a2 == 3 && f != 0) ||
                                 (a2 == 4 && g != 0) ||
                                 (a2 == 5 && h != 0) ||
                                 (a2 == 6 && i != 0) ||
                                 (a2 == 7 && j != 0) ||
                                 (a2 == 8 && k != 0) ||
                                 (a2 == 9 && l != 0));

                        if (a2 == 1) d = 2;
                        if (a2 == 2) e = 2;
                        if (a2 == 3) f = 2;
                        if (a2 == 4) g = 2;
                        if (a2 == 5) h = 2;
                        if (a2 == 6) i = 2;
                        if (a2 == 7) j = 2;
                        if (a2 == 8) k = 2;
                        if (a2 == 9) l = 2;

                        // Vê se a maquina venceu

                        if ((d == 2 && e == 2 && f == 2) ||
                            (g == 2 && h == 2 && i == 2) ||
                            (j == 2 && k == 2 && l == 2) ||
                            (d == 2 && g == 2 && j == 2) ||
                            (e == 2 && h == 2 && k == 2) ||
                            (f == 2 && i == 2 && l == 2) ||
                            (d == 2 && h == 2 && l == 2) ||
                            (f == 2 && h == 2 && j == 2))
                        {
                            Console.WriteLine("\nPerda");
                            fim = 1;
                        }

                        // Vê se deu empate

                        if (d != 0 && e != 0 && f != 0 &&
                            g != 0 && h != 0 && i != 0 &&
                            j != 0 && k != 0 && l != 0 &&
                            fim == 0)
                        {
                            Console.WriteLine("\nVelha");
                            fim = 1;
                        }
                    }
                }

                if (a == 2)
                {
                    Console.WriteLine("\t1\t|\t2\t|\t3");
                    Console.WriteLine("\t-----------------------------------");
                    Console.WriteLine("\t4\t|\t5\t|\t6");
                    Console.WriteLine("\t-----------------------------------");
                    Console.WriteLine("\t7\t|\t8\t|\t9");
                    Console.WriteLine("\nEscolha de 1 a 9 para jogar.");
                    Console.WriteLine("O jogador será 1 e a máquina será 2.");
                }

                if (a != 3)
                {
                    Console.WriteLine("\n1-Jogar");
                    Console.WriteLine("2-Instruções");
                    Console.WriteLine("3-Sair\n");
                    a = int.Parse(Console.ReadLine());
                }

            } while (a != 3);

            Console.WriteLine("Fechar programa");
            Console.ReadKey();
            
            //da proxima organiza desse jeito tbm, fica muito dificil mexer sem comentarios e tudo desalinhado, bem mais facil pra entender msm n sendo vc q fez
            //o unico "problema" é q n sai no meio do jogo,e o n acontece nd se o jogador coloca no msm lugar
            //mas acho q o professor vai aceitar, e n precisa colocar o if em linhas separadas, q fica muito longo,
            //mas ainda tem muitos if's, temos q aprender switch case, ctz q ia diminuir drasticamente a quantidadede de if.
        }
    }
}
